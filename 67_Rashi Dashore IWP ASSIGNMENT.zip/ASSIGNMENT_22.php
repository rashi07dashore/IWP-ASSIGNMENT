<!DOCTYPE html>
<html>
<body>

<?php
date_default_timezone_set('Asia/Kolkata');
$date = date('d-m-y h:i:s');
echo $date;

?>
<hr>
<p>By Rashi Dashore.</p>
<p> Roll No. : IC-2K20-67 </p>
Thankyou
<hr>

</body>
</html>
